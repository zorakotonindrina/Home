package etu1836.framework;
public class ModeleView {
    String view;

    
    public ModeleView() {
    }

    public ModeleView(String view) {
        this.view = view;
    }

    public String getView() {
        return view;
    }

    public void setView(String view) {
        this.view = view;
    }

}
